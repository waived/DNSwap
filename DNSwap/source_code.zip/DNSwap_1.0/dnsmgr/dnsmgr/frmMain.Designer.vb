﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.comboAdapter = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.comboProvider = New System.Windows.Forms.ComboBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtSecondary = New System.Windows.Forms.TextBox()
        Me.txtPrimary = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnFlush = New System.Windows.Forms.Button()
        Me.btnSwap = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Primary DNS"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.comboAdapter)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(384, 61)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Adapter"
        '
        'comboAdapter
        '
        Me.comboAdapter.BackColor = System.Drawing.SystemColors.Control
        Me.comboAdapter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboAdapter.ForeColor = System.Drawing.Color.Black
        Me.comboAdapter.FormattingEnabled = True
        Me.comboAdapter.Location = New System.Drawing.Point(14, 23)
        Me.comboAdapter.Name = "comboAdapter"
        Me.comboAdapter.Size = New System.Drawing.Size(356, 21)
        Me.comboAdapter.TabIndex = 2
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.comboProvider)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 79)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(384, 61)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "DNS Provider"
        '
        'comboProvider
        '
        Me.comboProvider.BackColor = System.Drawing.SystemColors.Control
        Me.comboProvider.DropDownHeight = 180
        Me.comboProvider.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboProvider.ForeColor = System.Drawing.Color.Black
        Me.comboProvider.FormattingEnabled = True
        Me.comboProvider.IntegralHeight = False
        Me.comboProvider.Items.AddRange(New Object() {"US - Google Public DNS", "US - OpenDNS", "RU - Yandex", "AU - Cloudflare", "US - Norton ConnectSafe Basic", "US - Level 3 - A", "US - Level 3 - B", "US - Level 3 - C", "US - Level 3 - D", "US - Comodo Secure", "US - Dyn", "US - Norton DNS", "US - Comodo", "US - VeriSign Public DNS", "US - Qwest", "US - Sprint", "DK - Censurfridns", "RU - Safe DNS", "DE - DNS WATCH", "AT - FreeDNS", "US - Sprintlink", "US - UltraDNS", "GB - Zen Internet", "GB - Orange DNS", "US - Hurricane Electric", "ES - puntCAT", "NL - Freenom World", "FR - FDN", "US - Neustar 1", "US - Neustar 2", "RU - AdGuard", "US - Quad9 Security", "US - Quad9 No Security", "BG - MegaLan"})
        Me.comboProvider.Location = New System.Drawing.Point(14, 23)
        Me.comboProvider.MaxDropDownItems = 12
        Me.comboProvider.Name = "comboProvider"
        Me.comboProvider.Size = New System.Drawing.Size(356, 21)
        Me.comboProvider.TabIndex = 2
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtSecondary)
        Me.GroupBox3.Controls.Add(Me.txtPrimary)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 146)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(384, 78)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Configure"
        '
        'txtSecondary
        '
        Me.txtSecondary.BackColor = System.Drawing.SystemColors.Control
        Me.txtSecondary.Location = New System.Drawing.Point(195, 39)
        Me.txtSecondary.Name = "txtSecondary"
        Me.txtSecondary.ReadOnly = True
        Me.txtSecondary.Size = New System.Drawing.Size(175, 20)
        Me.txtSecondary.TabIndex = 10
        Me.txtSecondary.Text = "8.8.4.4"
        Me.txtSecondary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPrimary
        '
        Me.txtPrimary.BackColor = System.Drawing.SystemColors.Control
        Me.txtPrimary.Location = New System.Drawing.Point(14, 39)
        Me.txtPrimary.Name = "txtPrimary"
        Me.txtPrimary.ReadOnly = True
        Me.txtPrimary.Size = New System.Drawing.Size(175, 20)
        Me.txtPrimary.TabIndex = 9
        Me.txtPrimary.Text = "8.8.8.8"
        Me.txtPrimary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(192, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Secondary DNS"
        '
        'btnRefresh
        '
        Me.btnRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.25!)
        Me.btnRefresh.Location = New System.Drawing.Point(12, 296)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(184, 28)
        Me.btnRefresh.TabIndex = 6
        Me.btnRefresh.Text = "REFRESH ADAPTERS"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'btnFlush
        '
        Me.btnFlush.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.25!)
        Me.btnFlush.Location = New System.Drawing.Point(212, 296)
        Me.btnFlush.Name = "btnFlush"
        Me.btnFlush.Size = New System.Drawing.Size(184, 28)
        Me.btnFlush.TabIndex = 7
        Me.btnFlush.Text = "FLUSH DNS CACHE"
        Me.btnFlush.UseVisualStyleBackColor = True
        '
        'btnSwap
        '
        Me.btnSwap.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSwap.Location = New System.Drawing.Point(12, 239)
        Me.btnSwap.Name = "btnSwap"
        Me.btnSwap.Size = New System.Drawing.Size(384, 44)
        Me.btnSwap.TabIndex = 8
        Me.btnSwap.Text = "SWAP YOUR DNS"
        Me.btnSwap.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(409, 339)
        Me.Controls.Add(Me.btnSwap)
        Me.Controls.Add(Me.btnFlush)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DNSwap  ─  Public 1.0"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents comboAdapter As ComboBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents comboProvider As ComboBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnRefresh As Button
    Friend WithEvents btnFlush As Button
    Friend WithEvents txtSecondary As TextBox
    Friend WithEvents txtPrimary As TextBox
    Friend WithEvents btnSwap As Button
End Class
