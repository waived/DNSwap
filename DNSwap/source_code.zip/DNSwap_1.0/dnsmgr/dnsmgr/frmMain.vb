﻿Imports System.Diagnostics
Imports System.Net
Imports System.Net.NetworkInformation
Public Class frmMain
    Private ifaces As NetworkInterface()
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        System.Threading.ThreadPool.QueueUserWorkItem(Sub() get_iface())

        comboProvider.SelectedIndex = 0
    End Sub

    Private Sub get_iface()
        CheckForIllegalCrossThreadCalls = False

        ifaces = NetworkInterface.GetAllNetworkInterfaces()

        For Each _iface As NetworkInterface In ifaces

            'only add interface/s that are operational
            If _iface.OperationalStatus = OperationalStatus.Up Then

                Dim iface_name As String = _iface.Name

                comboAdapter.Items.Add(iface_name)
            End If
        Next

        If Not comboAdapter.Items.Count = 0 Then
            comboAdapter.SelectedIndex = 0
        End If
    End Sub

    Private Sub comboProvider_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboProvider.SelectedIndexChanged
        If comboProvider.Text = "US - Google Public DNS" Then
            txtPrimary.Text = "8.8.8.8"
            txtSecondary.Text = "8.8.4.4"
        ElseIf comboProvider.Text = "US - OpenDNS" Then
            txtPrimary.Text = "208.67.222.222"
            txtSecondary.Text = "208.67.220.220"
        ElseIf comboProvider.Text = "RU - Yandex" Then
            txtPrimary.Text = "77.88.8.1"
            txtSecondary.Text = "77.88.8.8"
        ElseIf comboProvider.Text = "AU - Cloudflare" Then
            txtPrimary.Text = "1.1.1.1"
            txtSecondary.Text = "1.0.0.1"
        ElseIf comboProvider.Text = "US - Norton ConnectSafe Basic" Then
            txtPrimary.Text = "199.85.126.10"
            txtSecondary.Text = "199.85.127.10"
        ElseIf comboProvider.Text = "US - Level 3 - A" Then
            txtPrimary.Text = "209.244.0.3"
            txtSecondary.Text = "209.244.0.4"
        ElseIf comboProvider.Text = "US - Level 3 - B" Then
            txtPrimary.Text = "4.2.2.1"
            txtSecondary.Text = "4.2.2.2"
        ElseIf comboProvider.Text = "US - Level 3 - C" Then
            txtPrimary.Text = "4.2.2.3"
            txtSecondary.Text = "4.2.2.4"
        ElseIf comboProvider.Text = "US - Level 3 - D" Then
            txtPrimary.Text = "4.2.2.5"
            txtSecondary.Text = "4.2.2.6"
        ElseIf comboProvider.Text = "US - Comodo Secure" Then
            txtPrimary.Text = "8.26.56.26"
            txtSecondary.Text = "8.20.247.20"
        ElseIf comboProvider.Text = "US - Dyn" Then
            txtPrimary.Text = "216.146.35.35"
            txtSecondary.Text = "216.146.36.36"
        ElseIf comboProvider.Text = "US - Norton DNS" Then
            txtPrimary.Text = "198.153.192.1"
            txtSecondary.Text = "198.153.194.1"
        ElseIf comboProvider.Text = "US - Comodo" Then
            txtPrimary.Text = "156.154.70.22"
            txtSecondary.Text = "156.154.71.22"
        ElseIf comboProvider.Text = "US - VeriSign Public DNS" Then
            txtPrimary.Text = "64.6.64.6"
            txtSecondary.Text = "64.6.65.6"
        ElseIf comboProvider.Text = "US - Qwest" Then
            txtPrimary.Text = "205.171.3.65"
            txtSecondary.Text = "205.171.2.65"
        ElseIf comboProvider.Text = "US - Sprint" Then
            txtPrimary.Text = "204.97.212.10"
            txtSecondary.Text = "204.117.214.10"
        ElseIf comboProvider.Text = "DK - Censurfridns" Then
            txtPrimary.Text = "89.233.43.71"
            txtSecondary.Text = "91.239.100.100"
        ElseIf comboProvider.Text = "RU - Safe DNS" Then
            txtPrimary.Text = "195.46.39.39"
            txtSecondary.Text = "195.46.39.40"
        ElseIf comboProvider.Text = "DE - DNS WATCH" Then
            txtPrimary.Text = "84.200.69.80"
            txtSecondary.Text = "84.200.70.40"
        ElseIf comboProvider.Text = "AT - FreeDNS" Then
            txtPrimary.Text = "37.235.1.174"
            txtSecondary.Text = "37.235.1.177"
        ElseIf comboProvider.Text = "US - Sprintlink" Then
            txtPrimary.Text = "199.2.252.10"
            txtSecondary.Text = "204.97.212.10"
        ElseIf comboProvider.Text = "US - UltraDNS" Then
            txtPrimary.Text = "204.69.234.1"
            txtSecondary.Text = "204.74.101.1"
        ElseIf comboProvider.Text = "GB - Zen Internet" Then
            txtPrimary.Text = "212.23.8.1"
            txtSecondary.Text = "212.23.3.1"
        ElseIf comboProvider.Text = "GB - Orange DNS" Then
            txtPrimary.Text = "195.92.195.94"
            txtSecondary.Text = "195.92.195.95"
        ElseIf comboProvider.Text = "US - Hurricane Electric" Then
            txtPrimary.Text = "74.82.42.42"
            txtSecondary.Text = "<n/a>"
        ElseIf comboProvider.Text = "ES - puntCAT" Then
            txtPrimary.Text = "109.69.8.51"
            txtSecondary.Text = "<n/a>"
        ElseIf comboProvider.Text = "NL - Freenom World" Then
            txtPrimary.Text = "80.80.80.80"
            txtSecondary.Text = "80.80.81.81"
        ElseIf comboProvider.Text = "FR - FDN" Then
            txtPrimary.Text = "80.67.169.12"
            txtSecondary.Text = "80.67.169.40"
        ElseIf comboProvider.Text = "US - Neustar 1" Then
            txtPrimary.Text = "156.154.70.1"
            txtSecondary.Text = "156.154.71.1"
        ElseIf comboProvider.Text = "US - Neustar 2" Then
            txtPrimary.Text = "156.154.70.5"
            txtSecondary.Text = "156.154.71.5"
        ElseIf comboProvider.Text = "RU - AdGuard" Then
            txtPrimary.Text = "176.103.130.130"
            txtSecondary.Text = "176.103.130.131"
        ElseIf comboProvider.Text = "US - Quad9 Security" Then
            txtPrimary.Text = "9.9.9.9"
            txtSecondary.Text = "149.112.112.112"
        ElseIf comboProvider.Text = "US - Quad9 No Security" Then
            txtPrimary.Text = "9.9.9.10"
            txtSecondary.Text = "149.112.112.10"
        ElseIf comboProvider.Text = "BG - MegaLan" Then
            txtPrimary.Text = "95.111.55.251"
            txtSecondary.Text = "95.111.55.250"
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        System.Threading.ThreadPool.QueueUserWorkItem(Sub() get_iface())
    End Sub

    Private Sub btnFlush_Click(sender As Object, e As EventArgs) Handles btnFlush.Click
        Dim process As New Process()

        process.StartInfo.FileName = "ipconfig"
        process.StartInfo.Arguments = "/flushdns"
        process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        process.StartInfo.UseShellExecute = False
        process.StartInfo.CreateNoWindow = True

        Try
            process.Start()
            'process.WaitForExit()
            MessageBox.Show("DNS cache flushed successfully.", "Alert!")
        Catch ex As Exception
            MessageBox.Show("Critical error encountered!", "Alert!")
        End Try
    End Sub

    Private Sub btnSwap_Click(sender As Object, e As EventArgs) Handles btnSwap.Click
        btnSwap.Enabled = False
        System.Threading.ThreadPool.QueueUserWorkItem(Sub() _swap())
    End Sub

    Private Sub _swap()
        CheckForIllegalCrossThreadCalls = False

        Try
            'primary dns
            Dim process As New Process()
            process.StartInfo.FileName = "netsh"
            process.StartInfo.Arguments = "interface ip set dns name=" & comboAdapter.Text & " static " & txtPrimary.Text
            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            process.Start()
            process.WaitForExit()

            'secondary dns
            If Not txtSecondary.Text = "<n/a>" Then
                process.StartInfo.Arguments = "interface ip add dns name=" & comboAdapter.Text & " " & txtSecondary.Text & " index=2"
                process.Start()
                process.WaitForExit()
            End If

            MessageBox.Show("DNS information set successfully!", "Alert!")
        Catch ex As Exception
            Console.WriteLine("Error changing DNS: " & ex.Message)
        End Try

        btnSwap.Enabled = True
    End Sub
End Class
